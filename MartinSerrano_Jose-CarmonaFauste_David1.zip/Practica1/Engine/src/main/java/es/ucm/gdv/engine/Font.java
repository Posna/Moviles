package es.ucm.gdv.engine;

import java.awt.FontFormatException;
import java.io.IOException;

public interface Font {
    void init(String filename, int size, boolean isBold);
}
